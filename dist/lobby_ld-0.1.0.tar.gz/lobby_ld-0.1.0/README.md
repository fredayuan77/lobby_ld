# lobby_ld

python wrapper for lobbying disclosure API

## Installation

```bash
$ pip install lobby_ld
```

## Usage

- TODO

## Contributing

Interested in contributing? Check out the contributing guidelines. Please note that this project is released with a Code of Conduct. By contributing to this project, you agree to abide by its terms.

## License

`lobby_ld` was created by Freda Yuan. It is licensed under the terms of the MIT license.

## Credits

`lobby_ld` was created with [`cookiecutter`](https://cookiecutter.readthedocs.io/en/latest/) and the `py-pkgs-cookiecutter` [template](https://github.com/py-pkgs/py-pkgs-cookiecutter).
